import serial
import RPi.GPIO as GPIO
import os, time

GPIO.setmode(GPIO.BOARD)

# Enable Serial Communication
gsm = serial.Serial("/dev/ttyUSB0", baudrate=9600, timeout=1)

print("opened port : "+gsm.portstr)

if gsm.isOpen():
    #1
    gsm.write(b'AT\r\n')
    time.sleep(0.5)
    #2
    gsm.write(b'ATE0\r\n')
    time.sleep(0.5)
    #3
    gsm.write(b'AT+SAPBR=3,1,"CONTYPE","GPRS"\r\n')
    rcv = gsm.read(20)
    time.sleep(0.5)
    #4
    gsm.write(b'AT+SAPBR=3,1,"APN","matooma.m2m"\r\n')
    time.sleep(0.5)
    print("OK1:"+str(gsm.read(gsm.inWaiting())))
    #7
    gsm.write(b'AT+SAPBR=1,1\r\n')
    time.sleep(3)
    print("O89: "+str(gsm.read(gsm.inWaiting())))
    #8
    gsm.write(b'AT+SAPBR=2,1\r\n')
    time.sleep(1)
    #9
    gsm.write(b'AT+FTPCID=2\r\n')
    time.sleep(0.5)
    print("OK54: "+str(gsm.read(gsm.inWaiting())))
    #10
    gsm.write(b'AT+FTPMODE=1\r\n')
    time.sleep(0.5)
    #11
    gsm.write(b'AT+FTPSERV="ftpcloud.cluster024.hosting.ovh.net"\r\n')
    time.sleep(0.5)
    print("OK22: "+str(gsm.read(gsm.inWaiting())))
    #12
    gsm.write(b'AT+FTPPORT=21\r\n')
    time.sleep(0.5)
    #13
    gsm.write(b'AT+FTPUN="emasolw_ovh-43310"\r\n')
    rcv = gsm.read(20)
    print(gsm.read(gsm.inWaiting()))
    time.sleep(0.5)
    #14
    gsm.write(b'AT+FTPPW="dRMFf3HdQqn5"\r\n')
    rcv = gsm.read(20)
    time.sleep(0.5)
    #15
    gsm.write(b'AT+FTPPUTNAME="Demo.txt"\r\n')
    rcv = gsm.read(20)
    time.sleep(0.5)
    #16
    gsm.write(b'AT+FTPPUTPATH="/www/Test_RPI/"\r\n')
    time.sleep(0.5)
    #17
    gsm.write(b'AT+FTPPUT=1\r\n')
    time.sleep(10)
    #18
    gsm.write(b'AT+FTPPUT=2,49\r\n')
    time.sleep(1)
    gsm.write(b"This file is loaded from PYTHON script SIM900 GSM\r\n") #here i want load a file(*.txt) from "C:\data to load\new.txt"
    #gsm.write(b'\x1a') //and file size may vary so what I have give at FTPPUT=2,xxx?
    time.sleep(2)
    print(gsm.read(gsm.inWaiting()))
    #19
    gsm.write(b'AT+FTPPUT=2,0\r\n')
    time.sleep(6)
    #20
    gsm.write(b'AT+SAPBR=0,1,"CONTYPE","GPRS"\r\n')
    time.sleep(1)
    print(gsm.read(gsm.inWaiting()))