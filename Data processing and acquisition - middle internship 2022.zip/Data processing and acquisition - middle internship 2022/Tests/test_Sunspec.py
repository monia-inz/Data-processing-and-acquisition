import sys

sys.path.append('/home/pi/src/pysunspec2')

import sunspec2.modbus.client as client
import pytest
import socket
import sunspec2.tests.mock_socket as MockSocket
import serial
import sunspec2.tests.mock_port as MockPort

sys.path.append('/home/pi/src/git/RPI')
from Init_INV import Config_Sunspec

# def test_bit(n,b):
#     print(n)
#     n &= (1<<b)
#     print(1<<b)
#     print(n)
#     n = (n  == (1<<b))
#     return n

# value = 0b0101

# print(test_bit(value,2))


#############################################################
# read_register_test
#############################################################
# Fonction de test pour la lecture des csv, si les csv sont 
# ecrit de la bonne manière ce test ne retournera pas 
# d'erreurs
# * data_val sont les valeurs à recuperer. Chaque valeur est 
#   affectée à un registre. Ce test fait le lien entre les
#   registres
#############################################################

# def read_register_test(register, signed, position=1, debug=0):
#     global measures
#     value = 0
#     data_val = com.open_csv('Library/Init_test_val.csv')

#     if debug>1:
#         com._box('Checking register: ' +str(register+position-1))

#     i = 0
#     while  i <= len(data_val)-1 and (int(register)) != int(data_val[i]['varRegister']):
#         i +=1
#     value = data_val[i-1 + position]['varVal']

#     measures.append(value)
    
#     return value



def test(monkeypatch):

    my_Config = Config_Sunspec()
    print("HEYYY")
    for addr in my_Config.addr:
        monkeypatch.setattr(socket, 'socket', MockSocket.mock_socket)
        monkeypatch.setattr(serial, 'Serial', MockPort.mock_port)

        onduleurs = client.SunSpecModbusClientDeviceRTU(slave_id=addr, name="/dev/ttyS0", baudrate=9600)
        print(addr)
        rtu_buffer = [b'\x01\x03\x06SunS\x00\x01\x8d\xe4',
                        b'\x01\x03\x02\x00B',
                        b'8u',
                        b'\x01\x03\x88\x00\x01',
                        b'\x00BSunSpecTest\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                        b'\x00\x00\x00TestDevice-1\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                        b'\x00\x00\x00\x00opt_a_b_c\x00\x00\x00\x00\x00\x00\x001.2.3\x00\x00\x00\x00\x00\x00\x00\x00'
                        b'\x00\x00\x00sn-123456789\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                        b'\x00\x00\x00\x00\x01\x00\x00M\xf9',
                        b'\x01\x03\x02\x00~',
                        b'8d',
                        b'\x01\x03\x02\x00@',
                        b'\xb9\xb4',
                        b'\x01\x03\x84\x00~',
                        b'\x00@\x00\x03\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x80\x00\x80\x00\x80\x00'
                        b'\xff\xff\xff\xff\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff'
                        b'\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00'
                        b'\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff'
                        b'\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\xff\xff\x80\x00\x00\x00\x00\x00'
                        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff\xff\xffI',
                        b'\x01\x03\x02\xff\xff',
                        b'\xb9\xf4']
        onduleurs.open()
        onduleurs.client.serial._set_buffer(rtu_buffer)

        onduleurs.scan()

        file_var = my_Config.file_var[0]
        models = {}
        sun_models = my_Config.file_sun[0]

        for j in range(0, len(sun_models)):

            models.update(
            {
                sun_models[j]['varIndex']:
                sun_models[j]['varName']
            })

        for k in range(0, len(file_var)):
            if file_var[k]['varUse'] == "No":
                continue
        
            model = models[str(file_var[k]['varReqIndex'])]
            print("MODELE:"+model)
            variable = file_var[k]['varName']

            value = getattr(onduleurs,model)
            print("MODELELELEL: "+str(value[0]))
            variable = getattr(value[0], variable)
            value = variable.value
            print("VALEUR: " + str(value))
        
        # dd= onduleurs.volt_var[0]
        #print(dd.curve[])

# def func(x):
#     return x + 1


# def test_answer():
#     assert func(3) == 5