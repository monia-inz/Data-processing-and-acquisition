"""
Test de communication
"""
import sys
from datetime import datetime
import time
import os 

import csv
from CONFIG import *
import Library
import minimalmodbus

from Init_INV import Config_Sunspec
import Com_Lib as com

global measures
measures = []


#############################################################
# read_register_test
#############################################################
# Fonction de test pour la lecture des csv, si les csv sont 
# ecrit de la bonne manière ce test ne retournera pas 
# d'erreurs
# * data_val sont les valeurs à recuperer. Chaque valeur est 
#   affectée à un registre. Ce test fait le lien entre les
#   registres
#############################################################

def read_register_test(register, signed, position=1, debug=0):
    global measures
    value = 0
    data_val = com.open_csv('Library/Init_test_val.csv')

    if debug>1:
        com._box('Checking register: ' +str(register+position-1))

    i = 0
    while  i <= len(data_val)-1 and (int(register)) != int(data_val[i]['varRegister']):
        i +=1
    value = data_val[i-1 + position]['varVal']

    measures.append(value)

    return value


#############################################################
# show_current_values
#############################################################
# Fonction d'envoi de requête sur le port RS485 en Modbus
# * data_reg regroupe les différents groupes de registre
# * data_var regroupe toutes les variables récupérables. Pour
#   chaque ligne dans data_reg, si il existe plusieurs  
#   variables dans le même groupe de registre alors on 
#   incrémente la position dans data_var (on passe à la 
#   prochaine variable).
# * if data_var[count]['varReqIndex'] == data_var[count+1]['varReqIndex']:
#   Ici si la variable à la ligne "count" du csv possède le
#   même "ReqIndex" que celle a la ligne "ReqIndex+1" alors 
#   elle appartient au même groupe de registre
#############################################################

def show_current_values(data_var, data_reg, instr, i, debug):
    count = 0

    com._box()
    com._box("Current values")
    com._box(" ")

    for l in range(len(data_reg)):
        try:
            com._box(data_var[count]['varName'], instr.read_register(int(data_reg[l]['varStartRegister']), 1, 3, bool(data_var[count]['varSigned'])))
        except IOError:
            if debug > 1:               
                com._box("Failed to read from instrument")
        #com._box(data_var[count]['varName'], instr.read_register(int(data_reg[l]['reqStartRegister']), 1, 3, bool(data_var[count]['varSigned'])))
        #com._box(data_var[count]['varName'], read_register_test(int(data_reg[l]['reqStartRegister']), bool(data_var[count]['varSigned'])))

        read_register_test(int(data_reg[l]['reqStartRegister']), bool(data_var[count]['varSigned']),int(data_var[count]['varPosition']), debug)

        if data_var[count]['varReqIndex'] == data_var[count+1]['varReqIndex']:
            while data_var[count]['varReqIndex'] == data_var[count+1]['varReqIndex']: 
                count +=1
                try:
                    com._box(data_var[count]['varName'], instr.read_register(int(data_reg[l]['reqStartRegister'])+ int(data_var[count]['varPosition']) -1, 1, 3, bool(data_var[count]['varSigned'])))
                except IOError:
                    if debug > 1:
                        com._box("Failed to read from instrument")

                #com._box(data_var[count]['varName'], read_register_test(int(data_reg[l]['reqStartRegister']),bool(data_var[count]['varSigned']), int(data_var[count]['varPosition']) ))
                #read_register_test(int(data_reg[l]['reqStartRegister']), bool(data_var[count]['varSigned']), int(data_var[count]['varPosition']), debug)
            count +=1
        else:
            count +=1


def main(my_Config, verbosity):

    global measures
    inst = minimalmodbus.Instrument('/dev/ttyS0', 1)

    output_date = '_'+datetime.now().strftime("%y%m%d")+'_'+datetime.now().strftime("%H0000")
    Exists = com.check_csv(my_Config.output_file+output_date+".csv")

    for i in range(0,int(my_Config.number_of_inv)):

        if Exists:
            measures = []
            measures.append(datetime.now().strftime('%x-%X'))
            show_current_values(my_Config.file_var, my_Config.file_reg, inst, i, verbosity)
            com.write_csv_existing(my_Config.output_file+output_date+".csv",measures ,'a', i+1, my_Config.number_of_inv)

        else:
            measures = []
            com.write_csv(my_Config.output_file+output_date+".csv", ['MACHINE_NUMBER_'+str(i+1) ],'a')
            measures.append(datetime.now().strftime('%x-%X'))
            show_current_values(my_Config.file_var, my_Config.file_reg, inst, i, verbosity)
            com.write_csv(my_Config.output_file+output_date+".csv",measures ,'a')


if __name__=="__main__":
    main()