import os
import struct
import sys
import time
from datetime import datetime

import Com_Lib as com
import crcmod
import minimalmodbus
import serial
import binascii
from Init_INV import Alarms, Config
from Data_send_ftp import send_alarm

Trans_State = {
    0 : "Everything is OK.",
    51 : "Command is not implemented",
    52 : "Variable does not exist",
    53 : "Variable value is out of range",
    54 : "EEprom not accessible",
    55 : "Not Toggled Service Mode",
    56 : "Can not send the command to internal micro",
    57 : "Command not Executed",
    58 : "The variable is not available, retry"
}

STORED_VALUE = [
    "SN", "Pac", "Status"
]

def construct_inverter_query(
    address, 
    param0, 
    param1, 
    param2, 
    param3, 
    param4, 
    param5, 
    param6
):

    SendStatus = False
    ReceiveStatus = False

    crc16 = crcmod.mkCrcFun(0x11021, rev=False, initCrc=0xFFFF, xorOut=0xFFFF)

    SendData= bytes([int(address)])
    SendData= SendData + bytes([int(param0)])
    SendData= SendData + bytes([int(param1)])
    SendData= SendData + bytes([int(param2)])
    SendData= SendData + bytes([int(param3)])
    SendData= SendData + bytes([int(param4)])
    SendData= SendData + bytes([int(param5)])
    SendData= SendData + bytes([int(param6)])
  
    crc16 = crcmod.predefined.mkCrcFun('crc-16-mcrf4xx')
    # crc = crc16(SendData)
    # print(crc)
    # time.sleep(1)
    crc = crc16(SendData)

    crc = ~crc&0xFFFF
    # print(~crc&0xFFFF)
    crclo= (crc & 0xFF)
    crchi = ((crc >> 8) & 0xFF)
    # crc16.update(SendData)
    # crc = crc16.hexdigest()


    SendData= chr(int(address))
    SendData= SendData + chr(int(param0))
    SendData= SendData + chr(int(param1))
    SendData= SendData + chr(int(param2))
    SendData= SendData + chr(int(param3))
    SendData= SendData + chr(int(param4))
    SendData= SendData + chr(int(param5))
    SendData= SendData + chr(int(param6))
    SendData= SendData + chr(crclo)
    SendData= SendData + chr(crchi)

    return SendData


def open_serial_port(my_Config, addr, debug):
    """open serial port"""

    serial_port = minimalmodbus.Instrument(my_Config.port,int(addr))
    serial_port.serial.baudrate = my_Config.daq_Baudrate
    print(my_Config.daq_Baudrate)
    serial_port.serial.bytesize = 8
    serial_port.serial.parity = serial.PARITY_NONE
    serial_port.serial.stopbits = 1
    serial_port.serial.timeout=int(my_Config.daq_Timeout_RTU)/1000

    if debug > 2:
        serial_port.debug = True

    return serial_port


def read_inverter(query_string, serial_port):
    """Send the query to the inverter and read the response"""

    response = serial_port._communicate(query_string, 8)

    # # wait 1 second. Do not make it less than that
    # time.sleep(0.5)

    return response


def requested_State(
            serial_port, 
            address, 
            my_Config, 
            file_var, 
            inv_n,
            debug
):

    # switch={
    #     "50": "State",
    #     "52": "P/N Reading",
    #     "58": "Version Reading",
    #     "59": "MeasureDSP",
    #     "63": "SN",
    #     "65": "Manufacturing Week/Year",
    #     "68": "Cumultative energy",
    #     "70": "Time/Date",
    #     "72": "Firmware",
    #     "78": "Cumulated Energy",
    #     "101": "Sys Info",
    #     "105": "Sys P/N",
    #     "107": "Sys SN"
    # }  
    
    global measures
    global epice_tmp

    for i in range(0, len(file_var)):

        count_error = 0
        value = ""

        while count_error < 3:


            value, count_error = command_serial(
                address,
                file_var[i]['varRegister'],
                int(file_var[i]['varPos']), 
                int(file_var[i]['varGlobal']),
                serial_port 
                )
            
        measures.append(value) 
        
        if file_var[i]["varEpice"] !="0":

            epice_tmp.update({
                file_var[i]["varEpice"]:value
            }) 

        if value == "Err: 12":
            stat = "NOT OK"
            com.create_json(inv_n ,"Status", stat)
            break

        else:
            stat = "OK"
            com.create_json(inv_n ,"Status", stat)
            
        if file_var[i]["varName"] in STORED_VALUE:

            com.create_json(inv_n ,file_var[i]["varName"], value)


def routine_Acq(
    my_Config, 
    debug, 
    path_to_file_output,
    writing
):

    inverter_status = {}

    global measures
    global status_Alarms
    global current_Alarms
    global epice_tmp

    for i in range(0,int(my_Config.number_of_inv)):

        status_Alarms = {}
        epice_tmp = {}
        measures = []
        measures.append(com.date_now_utc())

        file_var = my_Config.file_var[i]
        #inst = minimalmodbus.Instrument('/dev/ttyS0',int(my_Config.addr[i]))

        serial_port = open_serial_port(my_Config, my_Config.addr[i], debug)

        requested_State(
            serial_port, 
            my_Config.addr[i], 
            my_Config, 
            file_var, 
            i+1,
            debug
        )

        current_Alarms.update(
            {
                "ONDULEUR_"+str(i+1): 
                status_Alarms
            }
        )
        
        if writing:

            max_key = com.max_key(epice_tmp)
            for j in range(0, max_key):
                
                measures.append("")

            for key in epice_tmp.keys():
                
                measures[int(key)+1]=epice_tmp[key]

            # com.check_new_inverter(
            #     path_to_file_output, 
            #     ['ONDULEUR_NUMERO_'+str(i+1) ],
            #     'a', 
            #     i+1, 
            #     file_var
            # )

            try:
                com.write_csv_existing(
                    path_to_file_output, 
                    measures,
                    'a', 
                    i+1, 
                    my_Config.number_of_inv,
                    True
                )

            except FileNotFoundError:

                path_to_file_output = com.create_date_file(my_Config.output_file)

                for k in range(0,int(my_Config.number_of_inv)):
    
                    com.write_csv_epice(
                        path_to_file_output, 
                        ['ONDULEUR_NUMERO_'+str(k+1)],
                        'a'
                    )

                os.chmod(path_to_file_output, 0o777)

                com.write_csv_existing(
                    path_to_file_output, 
                    measures,
                    'a', 
                    i+1, 
                    my_Config.number_of_inv,
                    True
                )

            # com.check_new_inverter(
            #     path_to_file_output, 
            #     ['ONDULEUR_NUMERO_'+str(i+1) ],
            #     'a', 
            #     i+1, 
            #     file_var
            # )

            # com.write_csv_existing(
            #     path_to_file_output, 
            #     measures,
            #     'a', 
            #     i+1, 
            #     my_Config.number_of_inv
            # )


def main(my_Config, debug, quit=False, writing_multiple = False):
    
    global status_Alarms
    global current_Alarms

    my_Alarms = Alarms(my_Config)
    my_Config.check_file_json(STORED_VALUE)

    # now_plus_10 = now + timedelta(minutes = 10)
    acquisition_time = com.time_ten()

    pid = str(os.getpid())
    pidfile = "/tmp/routine.pid"

    open(pidfile, 'w').write(pid)


    try:

        while True:

            current_Alarms= {}   

            # Precise date format  

            path_to_file_output = com.create_date_file(my_Config.output_file)

            if not os.path.isfile(path_to_file_output):
                Exists = False

            else:
                Exists = True

            if Exists == False:
                
                for k in range(0,int(my_Config.number_of_inv)):
    
                    com.write_csv_epice(
                        path_to_file_output, 
                        ['ONDULEUR_NUMERO_'+str(k+1)],
                        'a'
                    )

                os.chmod(path_to_file_output, 0o777)

                # for k in range(0,int(my_Config.number_of_inv)):

                #     file_var = my_Config.file_var[k]
                #     varIndex = []
                #     varIndex.append(0)

                #     for j in range(0,len(file_var)):

                #         varIndex.append(file_var[j]['varIndex'])

                #     com.write_csv(
                #         path_to_file_output, 
                #         ['ONDULEUR_NUMERO_'+str(k+1)],
                #         'a'
                #     )

                #     com.write_csv(
                #         path_to_file_output, 
                #         varIndex,
                #         'a'
                #     )

                # os.chmod(path_to_file_output, 0o777)

            if datetime.now() >= acquisition_time:
                
                routine_Acq(
                    my_Config, 
                    debug,
                    path_to_file_output,
                    writing = True
                )
                
                acquisition_time = com.time_ten()

                #now_plus_10 = datetime.now() + timedelta(minutes = 10)
                continue

            #log(verbosity, "/dev/ttyS0", my_Config.addr, my_Config.output_file)

            routine_Acq(
                my_Config,
                debug, 
                path_to_file_output,
                writing = writing_multiple
            )
            
            alarm, output_file_alarm = my_Alarms.compare_alarms(current_Alarms)

            if alarm:

                send_alarm(my_Config, output_file_alarm, debug)

            if quit == True:
                break

    finally:
        os.unlink(pidfile)


def command_serial(inverter_address, register, pos, global_t, serial_port):

    try:
        if "#" in register:
            return 0,5

        elif register == "68":

                query = construct_inverter_query(
                    inverter_address, 
                    register, 
                    pos, 
                    0, 
                    0, 
                    global_t, 
                    0, 
                    0
                )

                value = read_inverter(query, serial_port)

                value = minimalmodbus._bytestring_to_float(value[2:6], 2).encode("latin1")

        else:
            
            query = construct_inverter_query(
                inverter_address, 
                register, 
                pos, 
                global_t, 
                0, 
                0, 
                0, 
                0
            )
            
            value = read_inverter(query, serial_port)
            value = value + value[:3]   
            print("VALUE: "+minimalmodbus._hexlify(value))
            
            if register == "50":
                value = value[1:6]
                value = value[pos - 1]

            if register in ["52","63","105","107"]:
                value = value[:6]

            if register == "58":
                value = value[2:6]

            if register == "65":
                value = "W:"+value[2:4] +"Y"+value[4:6]

            if register == "59":
                value = minimalmodbus._bytestring_to_float(value[2:6], 2)

            if register in ["70","78"]:
                value = int(struct.unpack("h", value[2:3])) * pow(2, 24) + int(struct.unpack("h",value[3:4])) * pow(2, 16) + int(struct.unpack("h",value[4:5])) * pow(2, 8) + int(struct.unpack("h",value[5:6]))
            
            if register == "72":
                value = value[2:3]+"."+value[3:4]+"."+value[4:5]+"."+value[5:6]
            
            if register == "101":
                value = value[2:3]

            if register == "105":
                value = value[2:3]

        return value, 5
     
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print("Error: "+str(exc_type)+ " in "+ str(fname)+ " at line: " +str(exc_tb.tb_lineno))
        print("ERROR : "+str(e))
        return "0", 5
