<div class="tab-pane active" id="INV">
  <h4 class="mt-3"><?php echo _("Configuration installation") ;?></h4>
  <div class="row">
    <div class="form-group col-md-6">
      <!-- <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">   -->
        
        <label for="cbxchannel"><?php echo _("Mode:"); ?></label>
       
          <?php 
          $Modes = ["MB","PP"];
          foreach($Modes as $m){
            if(empty($_POST['inv_mode_sel'])){
              $inv_mode_sel=$myInvConfig['inv_mode'];
            }
            else{
              $inv_mode_sel=$_POST['inv_mode_sel'];
            }
            if($m === $inv_mode_sel){
              SelectorOptions('inv_mode_sel', $Modes, $inv_mode_sel, '?'); 
              //echo "<option value=$m selected='selected'>$m</option>";
            }
          }
          ?>
        </select>
      <br>
      <label for="cbxchannel"><?php echo _("Nombre d'onduleurs:"); ?></label>
      <?php if(empty($_POST['number_of_inv'])){
          $inv_n=$myInvConfig['inv_n'];
        }
        else{
          $inv_n=$_POST['number_of_inv'];
        }
      ?>
      <input type="text" class="form-control" name="number_of_inv" value="<?php echo $inv_n ?>")>
      <br>
      <input type="submit" class="btn btn-outline btn-primary" name="submit_inv" value="<?php echo _("Save settings"); ?>" />
      <!-- <input type="submit" name="submit_inv" value="Save">   -->
    <!-- </form> -->
    </div>
  </div>

  <div class="row">
    <div class="form-group col-md-6">
    <h4 class="mt-3"><?php echo _("Configuration des onduleurs") ;?></h4>
      <label for="cbxchannel"><?php echo _("Onduleur numéro"); ?></label>
      <?php
      $selectablechannels = Array();
      if(empty($_POST['inv_number'])){
        $inv_number="1";
      }
      else{
        $inv_number=$_POST['inv_number'];
      }
      
      for ($i = 1;$i <= $inv_n; $i++){
        $selectablechannels[$i] = $i;
      }
      $model="inv_model_";
      $model.=strval($inv_number-1);
      $var="inv_var_";
      $var.=strval($inv_number-1);
      $addr="inv_addr_";
      $addr.=strval($inv_number-1);

      $name_server_model="server_model_";
      $name_server_model.=strval($inv_number-1);
      $name_server_var="server_var_";
      $name_server_var.=strval($inv_number-1);
      $name_server_addr="server_addr_";
      $name_server_addr.=strval($inv_number-1);

      if(empty($_POST[$name_server_model])){
        $server_model=$myInvConfig[$model];
      }
      else{
        $server_model=$_POST[$name_server_model];
      }
      if(empty($_POST[$name_server_var])){
        $server_var=$myInvConfig[$var];
      }
      else{
        $server_var=$_POST[$name_server_var];
      }
      if(empty($_POST[$name_server_addr])){
        $server_addr=$myInvConfig[$addr];
      }
      else{
        $server_addr=$_POST[$name_server_addr];
      }

      $path_to_def="/home/pi/src/git/RPI/CONFIG/";
      $delete_list=['..',
      '.',
      '__init__.py',
      '__pycache__',
      'maker.sh',
      'requirements.txt',
      'INI_Time.ini',
      'INI_config.ini',
      'INI_INV.ini',
      'INV_models.txt'];

      $tmp_model_list=
        scandir($path_to_def);

      
      $path_to_def.=$server_model;

      $tmp_config_files=array_diff(scandir($path_to_def,1), array('..', '.'));
      SelectorOptions('inv_number', $selectablechannels, $inv_number, '?', "submit"); ?>

      <br>
      <label for="cbxchannel"><?php echo _("Modele:"); ?></label>
      <?php
      $model_list=array();
      for($i=0;$i<=sizeof($tmp_model_list);$i++){
        
        if(!empty($tmp_model_list[$i]) and (!in_array($tmp_model_list[$i],$delete_list))){
          array_push($model_list, $tmp_model_list[$i]);
        }
      }
      
      $config_files=array();
      for($i=0;$i<=sizeof($tmp_config_files);$i++){
        if(!empty($tmp_config_files[$i])){
          array_push($config_files, $tmp_config_files[$i]);
        }
      }
      ?>
      <?php SelectorOptions($name_server_model , $model_list, $server_model, '?', "submit"); ?><br>
      <!-- <input type="text" class="form-control" name="<?//php echo $name_server_model?>" value="<?//php echo $server_model ?>")> -->
      <!-- <input type="text" name=$model value="<?//php echo $server_model ?>")>-->
      
      <label for="cbxchannel"><?php echo _("Fichier de definition:"); ?></label>
      <!-- <input type="text"  class="form-control" name="<?//php echo $name_server_var ?>" value="<?//php echo $server_var ?>")><br> -->

      <?php SelectorOptions($name_server_var , $config_files, $server_var, '?'); ?><br>
      
      <label for="cbxchannel"><?php echo _("Adresse de l'onduleur:"); ?></label><br>
      <input type="text"  class="form-control" name="<?php echo $name_server_addr ?>" value="<?php echo $server_addr ?>")><br>

      <input type="submit" class="btn btn-outline btn-primary" name="submit_inv_false" value="Save">  
    </div>

  </div>
</div><!-- /.tab-pane | basic tab -->