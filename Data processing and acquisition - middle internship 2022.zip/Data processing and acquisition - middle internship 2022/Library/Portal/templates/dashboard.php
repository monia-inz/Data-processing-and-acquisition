<?php ob_start() ?>
  <?php if (!RASPI_MONITOR_ENABLED) : ?>
    <input type="submit" class="btn btn-warning" name ="RestartRoutine" value="<?php echo _("Restart Routine"); $msg=_("Restarting routine"); ?>" data-toggle="modal" data-target="#RestartModal"/>
    <div class="modal fade" id="RestartModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">  
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <div class="modal-title" id="ModalLabel"><i class="fas fa-sync-alt mr-2"></i><?php echo $msg ?></div>
          </div>
          <div class="modal-body">
            <div class="col-md-12 mb-3 mt-1"><?php echo _("Restarting the Routine") ?>...</div>
            <div class="progress" style="height: 20px;">
              <div class="progress-bar bg-info" role="progressbar" id="progressBar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="9"></div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline btn-primary" data-dismiss="modal"><?php echo _("Close"); ?></button>
          </div>
        </div>
      </div>
    </div>
  <?php endif ?>
<?php $buttons = ob_get_clean(); ob_end_clean() ?>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header">
        <div class="row">
    <div class="col">
      <i class="fas fa-tachometer-alt fa-fw mr-2"></i><?php echo _("Dashboard"); ?>
    </div>
    <div class="col">
      <button class="btn btn-light btn-icon-split btn-sm service-status float-right">
        <span class="icon"><i class="fas fa-circle service-status-<?php echo $ifaceStatus ?>"></i></span>
        <span class="text service-status"><?php echo strtolower($apInterface) .' '. _($ifaceStatus) ?></span>
      </button>
    </div>
        </div><!-- /.row -->
      </div><!-- /.card-header -->

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th><?php echo _("Inverter"); ?></th>
                <?php 
                $json =file_get_contents("/home/pi/src/git/RPI/Library/Portal/inverter_status.json");
                $obj = json_decode($json);
                $key=key($obj);
                
                $currentkey = $obj->$key;

                foreach($currentkey as $keys => $value){
                    echo "<th>$keys</th>";
                  }
                ?>
              </tr>
            </thead>
            <tbody>
              <?php
                $json =file_get_contents("/home/pi/src/git/RPI/Library/Portal/inverter_status.json");
                $obj = json_decode($json);

	              echo "<tr>";
                foreach ($obj as $name => $values) {
                  echo "<td>$name</td>";
                  foreach ($values as $k => $v) {
                    echo "<td>$v</td>";
                  }
                  echo "</tr>";
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card-body">
        <div class="row">

          <form role="form" action="dashboard" method="POST">
            <?php echo CSRFTokenFieldTag() ?>
            <ul><button type="button" onclick="window.location.reload();" class="btn btn-outline btn-primary" ><i class="fas fa-sync-alt"></i> <?php echo _("Refresh") ?></div></ul>
            <br>
            <?php echo $buttons ?>
            <!-- <input type ="submit" class="btn btn-warning" name="RestartRoutine" value="<?//php echo _("Restart Routine")?>"> -->
          </form>
      </div>

      <!-- </div>/.card-body -->
      <div class="card-body">
        <form role="form" action="dashboard" method="POST">
          <?php echo CSRFTokenFieldTag() ?>

          <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link active" id="INVtab" href="#INV" data-toggle="tab"><?php echo _("Onduleurs"); ?></a></li>
            <li class="nav-item"><a class="nav-link" id="configtab" href="#config" data-toggle="tab"><?php echo _("FTP"); ?></a></li>
            <li class="nav-item"><a class="nav-link" id="timetab" href="#time" data-toggle="tab"><?php echo _("Avancée"); ?></a></li>
          </ul>
        

          <div class="tab-content">
            <?php echo renderTemplate("dashboard/INV", $__template_data) ?>
            <?php echo renderTemplate("dashboard/CONFIG", $__template_data) ?>
            <?php echo renderTemplate("dashboard/TIME", $__template_data) ?>
          </div><!-- /.tab-content -->
          
          <?//php echo $buttons ?>
        </form>
      </div>

    </div><!-- /.card -->
  </div><!-- /.col-lg-12 -->
</div><!-- /.row -->
<script type="text/javascript"<?php //echo ' nonce="'.$csp_page_nonce.'"'; ?>>
// js translations:
var t = new Array();
t['send'] = '<?php echo addslashes(_('Send')); ?>';
t['receive'] = '<?php echo addslashes(_('Receive')); ?>';
</script>