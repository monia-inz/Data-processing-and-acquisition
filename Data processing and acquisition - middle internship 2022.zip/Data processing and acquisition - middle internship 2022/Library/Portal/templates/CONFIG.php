<div class="tab-pane fade" id="config">
  <h4 class="mt-3"><?php echo _("Configuration serveur") ;?></h4>
  <div class="row">
    <div class="form-group col-md-6">
      
      <!-- CARTE SIM -->
      <label for="cbxchannel"><?php echo _("Carte SIM?:"); ?></label>
      <?php
        $Modes = ["Oui","Non"];
        foreach($Modes as $m){
          if(empty($_POST['ftp_nosim'])){
            if($myFtpConfig['nosim']==false){
              $ftp_nosim="Oui";
            }
            elseif($myFtpConfig['nosim']==true){
              $ftp_nosim="Non";
            } 
            else{
              $ftp_nosim="Oui";
            }
          }
          else{
            $ftp_nosim=$_POST['ftp_nosim'];
          }
          if($m === $ftp_nosim){
            SelectorOptions('ftp_nosim', $Modes, $ftp_nosim, '?'); 
            break;
          }
          else{
            error_log("OK");
          }
        }
      ?>
      <br>

      <!-- NUMERO SIM -->
      <label for="cbxchannel"><?php echo _("Numero SIM:"); ?></label>
      <?php 
        if(empty($_POST['ftp_gprs_num'])){
          $ftp_gprs_num=$myFtpConfig['gprs_phonenumber'];
        }
        else{
          $ftp_gprs_num=$_POST['ftp_gprs_num'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_gprs_num" value="<?php echo $ftp_gprs_num ?>")>
      <br>

      <!-- APN -->
      <label for="cbxchannel"><?php echo _("APN:"); ?></label>
      <?php 
        if(empty($_POST['ftp_gprs_apn'])){
          $ftp_gprs_apn=$myFtpConfig['gprs_apn'];
        }
        else{
          $ftp_gprs_apn=$_POST['ftp_gprs_apn'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_gprs_apn" value="<?php echo $ftp_gprs_apn ?>")>
      <br>

      <!-- SERVEUR FTP -->
      <label for="cbxchannel"><?php echo _("Serveur FTP:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_name'])){
          $ftp_server_name=$myFtpConfig['ftp_server'];
        }
        else{
          $ftp_server_name=$_POST['ftp_server_name'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_name" value="<?php echo $ftp_server_name ?>")>
      <br>

      <!-- LOGIN FTP -->
      <label for="cbxchannel"><?php echo _("Login FTP:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_login'])){
          $ftp_server_login=$myFtpConfig['ftp_login'];
        }
        else{
          $ftp_server_login=$_POST['ftp_server_login'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_login" value="<?php echo $ftp_server_login ?>")>
      <br>

      <!-- PASSWORD FTP -->
      <label for="cbxchannel"><?php echo _("Password FTP:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_pwd'])){
          $ftp_server_pwd=$myFtpConfig['ftp_password'];
        }
        else{
          $ftp_server_pwd=$_POST['ftp_server_pwd'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_pwd" value="<?php echo $ftp_server_pwd ?>")>
      <br>

      <!-- DIRCONFIG -->
      <label for="cbxchannel"><?php echo _("Repertoire CONFIG:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_dirconfig'])){
          $ftp_server_dirconfig=$myFtpConfig['ftp_dirconfig'];
        }
        else{
          $ftp_server_dirconfig=$_POST['ftp_server_dirconfig'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_dirconfig" value="<?php echo $ftp_server_dirconfig ?>")>
      <br>

      <!-- DIRDATA -->
      <label for="cbxchannel"><?php echo _("Repertoire DATA:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_dirdata'])){
          $ftp_server_dirdata=$myFtpConfig['ftp_dirdata'];
        }
        else{
          $ftp_server_dirdata=$_POST['ftp_server_dirdata'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_dirdata" value="<?php echo $ftp_server_dirdata ?>")>
      <br>

      <!-- DIRDEF -->
      <label for="cbxchannel"><?php echo _("Repertoire DEF:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_dirdef'])){
          $ftp_server_dirdef=$myFtpConfig['ftp_dirdef'];
        }
        else{
          $ftp_server_dirdef=$_POST['ftp_server_dirdef'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_dirdef" value="<?php echo $ftp_server_dirdef ?>")>
      <br>

      <!-- DIRALARM -->
      <label for="cbxchannel"><?php echo _("Repertoire ALARM:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_diralarm'])){
          $ftp_server_diralarm=$myFtpConfig['ftp_diralarm'];
        }
        else{
          $ftp_server_diralarm=$_POST['ftp_server_diralarm'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_diralarm" value="<?php echo $ftp_server_diralarm ?>")>
      <br>

      <!-- DIRLOG -->
      <label for="cbxchannel"><?php echo _("Repertoire LOG:"); ?></label>
      <?php 
        if(empty($_POST['ftp_server_dirlog'])){
          $ftp_server_dirlog=$myFtpConfig['ftp_dirlog'];
        }
        else{
          $ftp_server_dirlog=$_POST['ftp_server_dirlog'];
        }
      ?>
      <input type="text" class="form-control" name="ftp_server_dirlog" value="<?php echo $ftp_server_dirlog ?>")>
      <br>

      <input type="submit" class="btn btn-outline btn-primary" name="submit_conf" value="<?php echo _("Save settings"); ?>" />
      <!-- <input type="submit" name="submit_inv" value="Save">   -->
    </div>
  </div>
</div><!-- /.tab-pane | basic tab -->