<div class="tab-pane fade" id="time">
  <h4 class="mt-3"><?php echo _("Configuration serveur") ;?></h4>
  <div class="row">
    <div class="form-group col-md-6">
      
      <!-- PORT -->
      <label for="cbxchannel"><?php echo _("PORT:"); ?></label>
      <?php
        $Modes = ["RS485","USB"];
        foreach($Modes as $m){
          if(empty($_POST['server_port'])){
            if($myTimeConfig['PORT']=="/dev/ttyS0"){
              $server_port="RS485";
            }
            elseif($myTimeConfig['PORT']=="/dev/tty_USB_DEVICE2"){
              $server_port="USB";
            } 
            else{
              $server_port="RS485";
            }
          }
          else{
            $server_port=$_POST['server_port'];
          }
          if($m === $server_port or empty($myTimeConfig['PORT'])){
            SelectorOptions('server_port', $Modes, $server_port, '?'); 
            break;
          }
          else{
            error_log("Erreur de lecture");
          }
        }
      ?>
      <br>

      <!-- FTP PERIOD -->
      <label for="cbxchannel"><?php echo _("Periode d'envoi FTP:"); ?></label>
      <?php 
        if(empty($_POST['server_ftp_period'])){
          $server_ftp_period=$myTimeConfig['ftp_period'];
        }
        else{
          $server_ftp_period=$_POST['server_ftp_period'];
        }
      ?>
      <input type="text" class="form-control" name="server_ftp_period" value="<?php echo $server_ftp_period ?>")>
      <br>

      <!-- MODE MODBUS -->
      <label for="cbxchannel"><?php echo _("Mode modbus:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_mode'])){
          $server_modbus_mode=$myTimeConfig['modbus_mode'];
        }
        else{
          $server_modbus_mode=$_POST['server_modbus_mode'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_mode" value="<?php echo $server_modbus_mode ?>")>
      <br>

      <!-- BAUDRATE -->
      <label for="cbxchannel"><?php echo _("Baudrate:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_baudrate'])){
          $server_modbus_baudrate=$myTimeConfig['modbus_baudrate'];
        }
        else{
          $server_modbus_baudrate=$_POST['server_modbus_baudrate'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_baudrate" value="<?php echo $server_modbus_baudrate ?>")>
      <br>

      <!-- PARITY -->
      <label for="cbxchannel"><?php echo _("Bit de parité:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_parity'])){
          $server_modbus_parity=$myTimeConfig['modbus_parity'];
        }
        else{
          $server_modbus_parity=$_POST['server_modbus_parity'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_parity" value="<?php echo $server_modbus_parity ?>")>
      <br>

      <!-- DATA BIT -->
      <label for="cbxchannel"><?php echo _("Bit de donnée:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_databit'])){
          $server_modbus_databit=$myTimeConfig['modbus_databit'];
        }
        else{
          $server_modbus_databit=$_POST['server_modbus_databit'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_databit" value="<?php echo $server_modbus_databit ?>")>
      <br>

      <!-- STOP BIT -->
      <label for="cbxchannel"><?php echo _("Bit de Stop:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_stopbit'])){
          $server_modbus_stopbit=$myTimeConfig['modbus_stopbit'];
        }
        else{
          $server_modbus_stopbit=$_POST['server_modbus_stopbit'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_stopbit" value="<?php echo $server_modbus_stopbit ?>")>
      <br>

      <!-- TIMEOUT TCP -->
      <label for="cbxchannel"><?php echo _("Timeout TCP:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_timeout_tcp'])){
          $server_modbus_timeout_tcp=$myTimeConfig['modbus_timeout_tcp'];
        }
        else{
          $server_modbus_timeout_tcp=$_POST['server_modbus_timeout_tcp'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_timeout_tcp" value="<?php echo $server_modbus_timeout_tcp ?>")>
      <br>

      <!-- TIMEOUT RTU -->
      <label for="cbxchannel"><?php echo _("Timeout RTU:"); ?></label>
      <?php 
        if(empty($_POST['server_modbus_timeout_rtu'])){
          $server_modbus_timeout_rtu=$myTimeConfig['modbus_timeout_rtu'];
        }
        else{
          $server_modbus_timeout_rtu=$_POST['server_modbus_timeout_rtu'];
        }
      ?>
      <input type="text" class="form-control" name="server_modbus_timeout_rtu" value="<?php echo $server_modbus_timeout_rtu ?>")>
      <br>

      <input type="submit" class="btn btn-outline btn-primary" name="submit_time" value="<?php echo _("Save settings"); ?>" />
      <!-- <input type="submit" name="submit_inv" value="Save">   -->
    </div>
  </div>
</div><!-- /.tab-pane | basic tab -->