<?php

require_once 'includes/config.php';
require_once 'includes/wifi_functions.php';
require_once 'includes/functions.php';
require_once 'app/lib/system.php';

/**
 * Show dashboard page.
 */
function DisplayDashboard(&$extraFooterScripts)
{   
    $path="/home/pi/src/git/RPI/CONFIG/INI_INV.ini";
    $path_conf="/home/pi/src/git/RPI/CONFIG/INI_config.ini";
    $path_time="/home/pi/src/git/RPI/CONFIG/INI_Time.ini";

    global $myInvConfig;
    global $myFtpConfig;
    global $myTimeConfig;

    $myInvConfig=parse_ini_file($path);
    $myFtpConfig=parse_ini_file($path_conf);
    $myTimeConfig=parse_ini_file($path_time);

    getWifiInterface();
    $status = new StatusMessages();
    // Need this check interface name for proper shell execution.
    if (!preg_match('/^([a-zA-Z0-9]+)$/', $_SESSION['wifi_client_interface'])) {
        $status->addMessage(_('Interface name invalid.'), 'danger');
        $status->showMessages();
        return;
    }

    if (!function_exists('exec')) {
        $status->addMessage(_('Required exec function is disabled. Check if exec is not added to php disable_functions.'), 'danger');
        $status->showMessages();
        return;
    }

    if (!RASPI_MONITOR_ENABLED) {
        $error = false;
        $put_ftp = false;
        if (isset($_POST['submit_inv'])) {
            $path="/home/pi/src/git/RPI/CONFIG/INI_INV.ini";
            SaveInvSettings($path, True);
            $error = false;
            $put_ftp = false;
        }
        if (isset($_POST['submit_inv_false'])) {
            $path="/home/pi/src/git/RPI/CONFIG/INI_INV.ini";
            SaveInvSettings($path, False);
            $put_ftp = true;
        }
        if (isset($_POST['submit_conf'])) {
            $path="/home/pi/src/git/RPI/CONFIG/INI_config.ini";
            SaveConfSettings($path);
            $put_ftp = true;
        }
        if (isset($_POST['submit_time'])) {
            $path="/home/pi/src/git/RPI/CONFIG/INI_Time.ini";
            SaveTimeSettings($path);
            $put_ftp = true;
            
        }
        
        $error = put_config_ftp($myFtpConfig, $status);
        
        if($error){
            $path="/home/pi/src/git/RPI/CONFIG/INI_config.ini";
            $myFtpConfig['local_edit']="True";
            // file_put_contents($path, "local_edit = True", FILE_APPEND);
            SaveConfSettings($path);
        }
        
    }
    if (!RASPI_MONITOR_ENABLED) {
        if (isset($_POST['RestartRoutine'])) {
            $status->addMessage('Attempting to start routine', 'info');
            exec('cat /tmp/routine.pid', $process_id, $exit_code);
            // foreach ($return as $line) {
            //     $status->addMessage($line, 'info');
            // }
            // exec('sudo bash -c /home/pi/src/git/RPI/Jobs/Routine_ACQ.sh -d', $return);
            // foreach ($return as $line) {
            //     $status->addMessage($line, 'info');
        }   
    }
    
    exec('ip a show '.$_SESSION['ap_interface'], $stdoutIp);
    $stdoutIpAllLinesGlued = implode(" ", $stdoutIp);
    $stdoutIpWRepeatedSpaces = preg_replace('/\s\s+/', ' ', $stdoutIpAllLinesGlued);

    preg_match('/link\/ether ([0-9a-f:]+)/i', $stdoutIpWRepeatedSpaces, $matchesMacAddr) || $matchesMacAddr[1] = _('No MAC Address Found');
    $macAddr = $matchesMacAddr[1];

    $ipv4Addrs = '';
    $ipv4Netmasks = '';
    if (!preg_match_all('/inet (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/([0-3][0-9])/i', $stdoutIpWRepeatedSpaces, $matchesIpv4AddrAndSubnet, PREG_SET_ORDER)) {
        $ipv4Addrs = _('No IPv4 Address Found');
    } else {
        foreach ($matchesIpv4AddrAndSubnet as $inet) {
            $address = $inet[1];
            $suffix  = (int) $inet[2];
            $netmask = long2ip(-1 << (32 - $suffix));

            $ipv4Addrs    .= " $address";
            $ipv4Netmasks .= " $netmask";
        }
        $ipv4Addrs    = trim($ipv4Addrs);
        $ipv4Netmasks = trim($ipv4Netmasks);
    }
    $ipv4Netmasks = empty($ipv4Netmasks) ? "-" : $ipv4Netmasks;

    $ipv6Addrs = '';
    if (!preg_match_all('/inet6 ([a-f0-9:]+)/i', $stdoutIpWRepeatedSpaces, $matchesIpv6Addr)) {
        $ipv6Addrs = _('No IPv6 Address Found');
    } else {
        if (isset($matchesIpv6Addr[1])) {
            $ipv6Addrs = implode(' ', $matchesIpv6Addr[1]);
        }
    }

    preg_match('/state (UP|DOWN)/i', $stdoutIpWRepeatedSpaces, $matchesState) || $matchesState[1] = 'unknown';
    $interfaceState = $matchesState[1];

    // Because of table layout used in the ip output we get the interface statistics directly from
    // the system. One advantage of this is that it could work when interface is disable.
    exec('cat /sys/class/net/'.$_SESSION['ap_interface'].'/statistics/rx_packets ', $stdoutCatRxPackets);
    $strRxPackets = _('No data');
    if (ctype_digit($stdoutCatRxPackets[0])) {
        $strRxPackets = $stdoutCatRxPackets[0];
    }

    exec('cat /sys/class/net/'.$_SESSION['ap_interface'].'/statistics/tx_packets ', $stdoutCatTxPackets);
    $strTxPackets = _('No data');
    if (ctype_digit($stdoutCatTxPackets[0])) {
        $strTxPackets = $stdoutCatTxPackets[0];
    }

    exec('cat /sys/class/net/'.$_SESSION['ap_interface'].'/statistics/rx_bytes ', $stdoutCatRxBytes);
    $strRxBytes = _('No data');
    if (ctype_digit($stdoutCatRxBytes[0])) {
        $strRxBytes = $stdoutCatRxBytes[0];
        $strRxBytes .= getHumanReadableDatasize($strRxBytes);
    }

    exec('cat /sys/class/net/'.$_SESSION['ap_interface'].'/statistics/tx_bytes ', $stdoutCatTxBytes);
    $strTxBytes = _('No data');
    if (ctype_digit($stdoutCatTxBytes[0])) {
        $strTxBytes = $stdoutCatTxBytes[0];
        $strTxBytes .= getHumanReadableDatasize($strTxBytes);
    }

    define('SSIDMAXLEN', 32);
    // Warning iw comes with: "Do NOT screenscrape this tool, we don't consider its output stable."
    exec('iw dev ' .$_SESSION['wifi_client_interface']. ' link ', $stdoutIw);
    $stdoutIwAllLinesGlued = implode('+', $stdoutIw); // Break lines with character illegal in SSID and MAC addr
    $stdoutIwWRepSpaces = preg_replace('/\s\s+/', ' ', $stdoutIwAllLinesGlued);

    preg_match('/Connected to (([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2}))/', $stdoutIwWRepSpaces, $matchesBSSID) || $matchesBSSID[1] = '';
    $connectedBSSID = $matchesBSSID[1];
    $connectedBSSID = empty($connectedBSSID) ? "-" : $connectedBSSID;

    $wlanHasLink = false;
    if ($interfaceState === 'UP') {
        $wlanHasLink = true;
    }

    if (!preg_match('/SSID: ([^+]{1,'.SSIDMAXLEN.'})/', $stdoutIwWRepSpaces, $matchesSSID)) {
        $wlanHasLink = false;
        $matchesSSID[1] = 'None';
    }

    $connectedSSID = $matchesSSID[1];

    preg_match('/freq: (\d+)/i', $stdoutIwWRepSpaces, $matchesFrequency) || $matchesFrequency[1] = '';
    $frequency = $matchesFrequency[1].' MHz';

    preg_match('/signal: (-?[0-9]+ dBm)/i', $stdoutIwWRepSpaces, $matchesSignal) || $matchesSignal[1] = '';
    $signalLevel = $matchesSignal[1];
    $signalLevel = empty($signalLevel) ? "-" : $signalLevel;

    preg_match('/tx bitrate: ([0-9\.]+ [KMGT]?Bit\/s)/', $stdoutIwWRepSpaces, $matchesBitrate) || $matchesBitrate[1] = '';
    $bitrate = $matchesBitrate[1];
    $bitrate = empty($bitrate) ? "-" : $bitrate;

    // txpower is now displayed on iw dev(..) info command, not on link command.
    exec('iw dev '.$_SESSION['wifi_client_interface'].' info ', $stdoutIwInfo);
    $stdoutIwInfoAllLinesGlued = implode(' ', $stdoutIwInfo);
    $stdoutIpInfoWRepSpaces = preg_replace('/\s\s+/', ' ', $stdoutIwInfoAllLinesGlued);

    preg_match('/txpower ([0-9\.]+ dBm)/i', $stdoutIpInfoWRepSpaces, $matchesTxPower) || $matchesTxPower[1] = '';
    $txPower = $matchesTxPower[1];

    // iw does not have the "Link Quality". This is a is an aggregate value,
    // and depends on the driver and hardware.
    // Display link quality as signal quality for now.
    $strLinkQuality = 0;
    if ($signalLevel > -100 && $wlanHasLink) {
        if ($signalLevel >= 0) {
            $strLinkQuality = 100;
        } else {
            $strLinkQuality = 100 + intval($signalLevel);
        }
    }

    $wlan0up = false;
    $classMsgDevicestatus = 'warning';
    if ($interfaceState === 'UP') {
        $wlan0up = true;
        $classMsgDevicestatus = 'success';
    }

    $arrHostapdConf = parse_ini_file('/etc/raspap/hostapd.ini');

    if (!RASPI_MONITOR_ENABLED) {
        if (isset($_POST['ifdown_wlan0'])) {
            // Pressed stop button
            if ($interfaceState === 'UP') {
                $status->addMessage(sprintf(_('Interface is going %s.'), _('down')), 'warning');
                exec('sudo ip link set '.$_SESSION['wifi_client_interface'].' down');
                $wlan0up = false;
                $status->addMessage(sprintf(_('Interface is now %s.'), _('down')), 'success');
            } elseif ($interfaceState === 'unknown') {
                $status->addMessage(_('Interface state unknown.'), 'danger');
            } else {
                $status->addMessage(sprintf(_('Interface already %s.'), _('down')), 'warning');
            }
        } elseif (isset($_POST['ifup_wlan0'])) {
            // Pressed start button
            if ($interfaceState === 'DOWN') {
                $status->addMessage(sprintf(_('Interface is going %s.'), _('up')), 'warning');
                exec('sudo ip link set ' .$_SESSION['wifi_client_interface']. ' up');
                exec('sudo ip -s a f label ' . $_SESSION['wifi_client_interface']);
                $wlan0up = true;
                $status->addMessage(sprintf(_('Interface is now %s.'), _('up')), 'success');
            } elseif ($interfaceState === 'unknown') {
                $status->addMessage(_('Interface state unknown.'), 'danger');
            } else {
                $status->addMessage(sprintf(_('Interface already %s.'), _('up')), 'warning');
            }
        } else {
            $status->addMessage(sprintf(_('Interface is %s.'), strtolower($interfaceState)), $classMsgDevicestatus);
        }
    }
    // brought in from template
    $arrHostapdConf = parse_ini_file(RASPI_CONFIG.'/hostapd.ini');
    $bridgedEnable = $arrHostapdConf['BridgedEnable'];
    $clientInterface = $_SESSION['wifi_client_interface'];
    $apInterface = $_SESSION['ap_interface'];
    $MACPattern = '"([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}"';

    if (getBridgedState()) {
        $moreLink = "hostapd_conf";
        exec('iw dev ' . $apInterface . ' station dump | grep -oE ' . $MACPattern, $clients);
    } else {
        $moreLink = "dhcpd_conf";
        exec('cat ' . RASPI_DNSMASQ_LEASES . '| grep -E $(iw dev ' . $apInterface . ' station dump | grep -oE ' . $MACPattern . ' | paste -sd "|")', $clients);
    }
    $ifaceStatus = $wlan0up ? "up" : "down";

    echo renderTemplate(
        "dashboard", compact(
            "clients",
            "moreLink",
            "apInterface",
            "clientInterface",
            "ifaceStatus",
            "bridgedEnable",
            "myInvConfig",
            "myFtpConfig",
            "myTimeConfig",
            "status",
            "ipv4Addrs",
            "ipv4Netmasks",
            "ipv6Addrs",
            "macAddr",
            "strRxPackets",
            "strRxBytes",
            "strTxPackets",
            "strTxBytes",
            "connectedSSID",
            "connectedBSSID",
            "bitrate",
            "signalLevel",
            "txPower",
            "frequency",
            "strLinkQuality",
            "wlan0up"
        )
    );
    $extraFooterScripts[] = array('src'=>'app/js/dashboardchart.js', 'defer'=>false);
    $extraFooterScripts[] = array('src'=>'app/js/linkquality.js', 'defer'=>false);
}

function SaveInvSettings($path, $only_inv = False)
{   
    global $myInvConfig;
    global $myFtpConfig;
    $result=$_POST['inv_number'];
    //$result.=strval($_POST['inv_n']);
    $myInvConfig['inv_n']=$_POST['number_of_inv'];
    $myInvConfig['inv_mode']=$_POST['inv_mode_sel'];

    if(!$only_inv){

        for ($i = 1;$i <= $myInvConfig['inv_n']; $i++){
            $model="inv_model_";$model.=strval($i-1);$var="inv_var_";
            $var.=strval($i-1);$addr="inv_addr_";$addr.=strval($i-1);

            $tmp_server_model="server_model_";$tmp_server_model.=strval($i-1);$tmp_server_var="server_var_";
            $tmp_server_var.=strval($i-1);$tmp_server_addr="server_addr_";$tmp_server_addr.=strval($i-1);

            if(!empty($_POST[$tmp_server_model])){
                $myInvConfig[$model]=$_POST[$tmp_server_model];
            }
            if(!empty($_POST[$tmp_server_var])){
                $myInvConfig[$var]=$_POST[$tmp_server_var];
            }
            if(!empty($_POST[$tmp_server_addr])){
                $myInvConfig[$addr]=$_POST[$tmp_server_addr];
            }
        }
    }
    write_php_ini_config($myInvConfig, $path, "[CONFIG-INV]");
    
}

function SaveConfSettings($path)
{   
    global $myFtpConfig;
    if($_POST['ftp_nosim']=="Oui"){
        $myFtpConfig['nosim']="False";
    }
    else{
        $myFtpConfig['nosim']="True";
    }
    
    $myFtpConfig['gprs_phonenumber']=$_POST['ftp_gprs_num'];
    $myFtpConfig['gprs_apn']=$_POST['ftp_gprs_apn'];
    $myFtpConfig['ftp_server']=$_POST['ftp_server_name'];
    $myFtpConfig['ftp_login']=$_POST['ftp_server_login'];
    $myFtpConfig['ftp_password']=$_POST['ftp_server_pwd'];
    $myFtpConfig['ftp_dirconfig']=$_POST['ftp_server_dirconfig'];
    $myFtpConfig['ftp_dirdata']=$_POST['ftp_server_dirdata'];
    $myFtpConfig['ftp_dirdef']=$_POST['ftp_server_dirdef'];
    $myFtpConfig['ftp_diralarm']=$_POST['ftp_server_diralarm'];
    $myFtpConfig['ftp_dirlog']=$_POST['ftp_server_dirlog'];

    write_php_ini_config($myFtpConfig, $path, "[FTP]");
    
}

function SaveTimeSettings($path)
{   
    global $myTimeConfig;
    global $myFtpConfig;
    if($_POST['server_port']=="USB"){
        $myTimeConfig['PORT']="/dev/ttyUSB_DEVICE2";
    }
    else{
        $myTimeConfig['PORT']="/dev/ttyS0";
    }
    
    $myTimeConfig['ftp_period']=$_POST['server_ftp_period'];
    $myTimeConfig['modbus_mode']=$_POST['server_modbus_mode'];
    $myTimeConfig['modbus_baudrate']=$_POST['server_modbus_baudrate'];
    $myTimeConfig['modbus_parity']=$_POST['server_modbus_parity'];
    $myTimeConfig['modbus_databit']=$_POST['server_modbus_databit'];
    $myTimeConfig['modbus_stopbit']=$_POST['server_modbus_stopbit'];
    $myTimeConfig['modbus_timeout_tcp']=$_POST['server_modbus_timeout_tcp'];
    $myTimeConfig['modbus_timeout_rtu']=$_POST['server_modbus_timeout_rtu'];

    write_php_ini_config($myTimeConfig, $path, "[CONFIG-ACQ]");
    
}