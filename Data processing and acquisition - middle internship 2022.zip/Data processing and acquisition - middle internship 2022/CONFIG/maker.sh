#! /bin/bash

. /home/pi/src/git/RPI/CONFIG/INI_Time.ini

period="$daq_period"
ftp_period="$ftp_period"

cmd="bash -c \"/home/pi/src/git/RPI/Jobs/Routine_ACQ.sh -d\" >> /var/log/out.txt"
entry="*/$period * * * * $cmd"

cmd_ftp="bash -c \"/home/pi/src/git/RPI/Jobs/Routine_FTP.sh -d\" >> /var/log/out_ftp.txt"
entry_ftp="$ftp_period * * * * $cmd_ftp"

cmd_wipe="bash -c \"/home/pi/src/git/RPI/Jobs/Routine_Wipe.sh -d\" >> /var/log/out_ftp.txt"
entry_wipe="* 12 * * * $cmd_wipe"

printf "we want to add this entry:\n$entry\n\n" 
escapedEntry=$(printf '%s\n' "$entry" | sed 's:[][\/.^$*]:\\&:g') 

printf "we want to add this entry:\n$entry_ftp\n\n" 
escapedEntry_ftp=$(printf '%s\n' "$entry_ftp" | sed 's:[][\/.^$*]:\\&:g') 

printf "we want to add this entry:\n$entry_wipe\n\n" 
escapedEntry_wipe=$(printf '%s\n' "$entry_wipe" | sed 's:[][\/.^$*]:\\&:g') 

if [[ $(crontab -l | egrep -v '^(#|$)' | grep -q "$escapedEntry"; echo $?) == 1 ]]
then
    printf "all clear; pattern was not already present; adding command to crontab hourly:\n$cmd\n\n"
    (crontab -l ; printf "$entry\n\n") | crontab -
else
    printf "pattern already present; no action taken\n\n"
fi

if [[ $(crontab -l | egrep -v '^(#|$)' | grep -q "$escapedEntry_ftp"; echo $?) == 1 ]]
then
    printf "all clear; pattern was not already present; adding command to crontab hourly:\n$cmd_ftp\n\n"
    (crontab -l ; printf "$entry_ftp\n\n") | crontab -
else
    printf "pattern already present; no action taken\n\n"
fi

if [[ $(crontab -l | egrep -v '^(#|$)' | grep -q "$escapedEntry_wipe"; echo $?) == 1 ]]
then
    printf "all clear; pattern was not already present; adding command to crontab hourly:\n$cmd_wipe\n\n"
    (crontab -l ; printf "$entry_wipe\n\n") | crontab -
else
    printf "pattern already present; no action taken\n\n"
fi

cd /home/pi/src/git/RPI/DATA/ALARM
rm LATEST_ALARM.txt

python3 - <<START
import sys
sys.path.append('/home/pi/src/git/RPI')
from Init_INV import Config, Alarms
my_Config = Config()
Alarms(my_Config)
print("Alarms are set")
START