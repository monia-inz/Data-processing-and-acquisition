#!/bin/bash
#!/usr/bin/env python3
HOME=/home/pi
LOGNAME=pi
PATH=/home/pi/bin/git/Jobs:/home/pi/bin/git:/home/pi/bin/:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games
SHELL=/bin/bash
USER=pi
PWD=/home/pi

json_path=/home/pi/src/git/RPI/DATA/tmp_values/inverter_values.json

cd /home/pi/src/git/RPI

lancement()
{
    
    if [ -e $json_path ]
    then
        rm $json_path
    fi

    python3 Routine.py $1
}

ps up `cat /tmp/routine.pid ` >/dev/null && echo "Running" || lancement $1




