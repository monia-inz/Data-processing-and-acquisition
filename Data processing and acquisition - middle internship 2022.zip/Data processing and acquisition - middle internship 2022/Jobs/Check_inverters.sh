#!/bin/bash
#!/usr/bin/env python3
HOME=/home/pi
LOGNAME=pi
PATH=/home/pi/bin/git/Jobs:/home/pi/bin/git:/home/pi/bin/:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games
SHELL=/bin/bash
USER=pi
PWD=/home/pi

cd /home/pi/src/git/RPI

ps up `cat /tmp/routine.pid ` >/dev/null && sudo kill -9 `cat /tmp/routine.pid` || echo "Not running"

python3 Routine.py $1 "check"

