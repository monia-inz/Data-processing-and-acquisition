#!/bin/bash

variable=$(ls /home/pi/src/git/RPI/DATA/tmp | wc -l)
variable2=$(ls /home/pi/src/git/RPI/DATA/ALARM/tmp | wc -l)

if [[ $variable -ge 100 ]]
then
    cd /home/pi/src/git/RPI/DATA/tmp
    rm *.gz
else
    printf "Nothing to do"
fi

if [[ $variable2 -ge 100 ]]
then
    cd /home/pi/src/git/RPI/DATA/ALARM/tmp
    rm *.csv
else
    printf "Nothing to do"
fi
