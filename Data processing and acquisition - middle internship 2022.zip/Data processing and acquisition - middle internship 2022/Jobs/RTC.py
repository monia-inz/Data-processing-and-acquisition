import serial
import time
import sys
from datetime import datetime
import os

sys.path.append('/home/pi/src/git/RPI/')

import Com_Lib as com

os.system("sudo systemctl stop gammu-smsd.service")

gsm = serial.Serial("/dev/ttyUSB_DEVICE1", baudrate=9600, timeout=1)
timeout = time.time() + 30

count = 0

while not gsm.isOpen():
    time.sleep(0.5)
    count= count+1
    if count >= 50:
        break

if not gsm.isOpen():
   
    com._box("early exit")
    os.system("sudo systemctl start gammu-smsd.service")
    sys.exit(2)

gsm.write(b'AT+CCLK?\r\n')

time.sleep(0.1)
com._box("Gammu stopped")
data=""
connected = False
err = True

timeout = time.time() + 20
count = 0

while not connected:
#serin = ser.read()
    connected = True
    
    while data.find("OK") == -1:
        count = count + 1     
        if (gsm.inWaiting()>0):
            #tmp = str(gsm.read(gsm.inWaiting()),'utf-8')
            data = data + gsm.read(gsm.inWaiting()).decode('cp437') 
            
        if time.time() < timeout:
            time.sleep(0.01) 
            continue
        if count >= 1000:
            gsm.write(b'AT+CCLK?\r\n')

        else:
            com._box("exiting")
            os.system("sudo systemctl start gammu-smsd.service")
            sys.exit(2)
    
index_start = data.find("\"", 0,1500)

if index_start != -1:
    index_end = data.find("\"",index_start+1,1500)

    if index_end != -1:
        string = data[index_start+1:index_end]
        Erreur = False
    else:
        com._box("not date")
        Erreur = True

else:
    com._box("Not good")
    Erreur = True
    
if not Erreur:
    # 21/05/26,16:35:54+08
    date_time = datetime.strptime(string[:17], '%y/%m/%d,%H:%M:%S')
    # date = "20"+string[:2]-string[]

    com._box("The date retrieved by rtc is: "+str(date_time))

    os.system("sudo date -s '"+str(date_time)+"'")

os.system("sudo systemctl start gammu-smsd.service")
