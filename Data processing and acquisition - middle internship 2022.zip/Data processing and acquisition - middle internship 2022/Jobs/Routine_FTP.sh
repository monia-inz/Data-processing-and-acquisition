#!/bin/bash
#!/usr/bin/env python3
HOME=/home/pi
LOGNAME=pi
PATH=/home/pi/bin/git/Jobs:/home/pi/bin/git:/home/pi/bin/:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games
SHELL=/bin/bash
USER=pi
PWD=/home/pi

systemctl stop gammu-smsd.service

cd /home/pi/src/git/RPI/DATA/
variable=$(ls -t1 *.csv)

gzip $variable

cd /home/pi/src/git/RPI

python3 Data_send_ftp.py $1

systemctl start gammu-smsd.service

